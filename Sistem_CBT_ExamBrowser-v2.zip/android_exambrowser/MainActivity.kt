package com.example.exambrowser

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Bundle
import android.util.Base64
import android.view.KeyEvent
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.journeyapps.barcodescanner.ScanContract
import com.journeyapps.barcodescanner.ScanOptions

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val pinPengawas = "1234"
    private var ujianAktif = false
    private var toneGen: ToneGenerator? = null

    private val qrPrefix = "EXAMSEC::"
    private val secretHeader = mapOf("X-Exam-Client" to "EXAM-SECURE-2026")

    private val barcodeLauncher = registerForActivityResult(ScanContract()) { result ->
        if (result.contents == null) {
            Toast.makeText(this, "Scan dibatalkan", Toast.LENGTH_SHORT).show()
            tampilkanMenuScan()
        } else {
            prosesQrTerenkripsi(result.contents.trim())
        }
    }

    private val requestCameraPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            bukaKameraScanQR()
        } else {
            Toast.makeText(this, "Izin kamera wajib diaktifkan untuk scan QR Ujian!", Toast.LENGTH_LONG).show()
            tampilkanMenuScan()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )

        setContentView(R.layout.activity_main)
        webView = findViewById(R.id.webViewUjian)
        toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)

        setupWebView()
        setupBackButtonProtection()
        tampilkanMenuScan()
    }

    private fun tampilkanMenuScan() {
        AlertDialog.Builder(this)
            .setTitle("Exam Browser Terkunci")
            .setMessage("Silakan pindai QR Code Ujian yang ditampilkan oleh pengawas.")
            .setCancelable(false)
            .setPositiveButton("Scan QR Ujian") { _, _ ->
                cekIzinKameraDanScan()
            }
            .show()
    }

    private fun cekIzinKameraDanScan() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) {
            bukaKameraScanQR()
        } else {
            requestCameraPermission.launch(Manifest.permission.CAMERA)
        }
    }

    private fun bukaKameraScanQR() {
        val options = ScanOptions().apply {
            setPrompt("Arahkan kamera ke QR Code Ujian")
            setBeepEnabled(true)
            setOrientationLocked(true)
        }
        barcodeLauncher.launch(options)
    }

    private fun prosesQrTerenkripsi(qrData: String) {
        if (!qrData.startsWith(qrPrefix)) {
            Toast.makeText(this, "QR Code tidak valid atau bukan QR Ujian resmi!", Toast.LENGTH_LONG).show()
            tampilkanMenuScan()
            return
        }
        try {
            val encodedPart = qrData.removePrefix(qrPrefix)
            val decodedBytes = Base64.decode(encodedPart, Base64.DEFAULT)
            val urlAsli = String(decodedBytes, Charsets.UTF_8)
            mulaiKunciUjian(urlAsli)
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal membaca enkripsi QR Code", Toast.LENGTH_SHORT).show()
            tampilkanMenuScan()
        }
    }

    private fun mulaiKunciUjian(url: String) {
        ujianAktif = true
        webView.loadUrl(url, secretHeader)
        try {
            startLockTask()
        } catch (e: Exception) {
            Toast.makeText(this, "Aktifkan Sematkan Layar (Screen Pinning)", Toast.LENGTH_LONG).show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            builtInZoomControls = false
            displayZoomControls = false
        }
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                request?.url?.toString()?.let { nextUrl ->
                    view?.loadUrl(nextUrl, secretHeader)
                }
                return true
            }
        }
    }

    override fun onMultiWindowModeChanged(isInMultiWindowMode: Boolean) {
        super.onMultiWindowModeChanged(isInMultiWindowMode)
        if (isInMultiWindowMode && ujianAktif) {
            bunyikanAlarm()
            Toast.makeText(this, "DILARANG SPLIT SCREEN!", Toast.LENGTH_LONG).show()
            finishAffinity()
        }
    }

    override fun onStop() {
        super.onStop()
        if (ujianAktif) {
            bunyikanAlarm()
        }
    }

    private fun bunyikanAlarm() {
        toneGen?.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 3000)
    }

    private fun setupBackButtonProtection() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Toast.makeText(this@MainActivity, "Tekan tombol Volume Bawah untuk keluar", Toast.LENGTH_SHORT).show()
            }
        })
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) {
            tampilkanDialogKeluar()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun tampilkanDialogKeluar() {
        val inputPin = EditText(this).apply {
            hint = "Masukkan PIN Pengawas"
        }

        AlertDialog.Builder(this)
            .setTitle("Akhiri Sesi Ujian")
            .setView(inputPin)
            .setPositiveButton("Keluar") { _, _ ->
                if (inputPin.text.toString() == pinPengawas) {
                    ujianAktif = false
                    try { stopLockTask() } catch (_: Exception) {}
                    finishAffinity()
                } else {
                    Toast.makeText(this, "PIN Salah!", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Batal", null)
            .show()
    }
}
