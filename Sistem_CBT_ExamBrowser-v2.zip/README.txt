SISTEM CBT AI GENERATOR + ANDROID EXAM BROWSER (v2 - TERUJI)
===========================================================

1. SERVER PYTHON (folder: server_python/)
   - Instal library:
     pip install -r requirements.txt
   - Buka app.py, isi GEMINI_API_KEY, sesuaikan NAMA_SEKOLAH, dan ganti password default ("guru123").
   - (Opsional) Letakkan file logo "tutwuri.png" di dalam folder server_python/ untuk watermark cetak PDF.
   - Jalankan server:
     python app.py
   - Buka http://localhost:5000 (Login default: admin / guru123).

2. APLIKASI ANDROID (folder: android_exambrowser/)
   - Buat proyek baru di Android Studio (Empty Views Activity - Kotlin).
   - Tambahkan library ZXing di build.gradle.kts sesuai file dependencies_gradle.txt.
   - Salin AndroidManifest.xml, activity_main.xml, dan MainActivity.kt ke folder proyek.
   - Klik Build -> Build Bundle(s) / APK(s) -> Build APK(s).
